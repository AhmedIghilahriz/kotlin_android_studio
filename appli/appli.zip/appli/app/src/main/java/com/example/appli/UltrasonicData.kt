package com.example.appli

class UltrasonicData {
    var distance: Int = 0
    var timestamp: String = ""
}